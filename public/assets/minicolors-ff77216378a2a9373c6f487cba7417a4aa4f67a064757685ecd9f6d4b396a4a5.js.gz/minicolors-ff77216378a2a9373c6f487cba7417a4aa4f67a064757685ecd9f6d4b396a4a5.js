(function() {
  $(function() {
    return $('input#color-picker').minicolors({
      theme: 'bootstrap'
    });
  });

}).call(this);
