/*$(document).bind("ajaxStart", function(){
  $("#filterrific_results").hide();
   $("#spinner").removeClass('hidden');
 })

 $(document).bind("ajaxComplete", function(){
   $("#filterrific_results").show();
   $("#spinner").addClass('hidden');
 });
